function varargout = GUI_V1(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI_V1_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI_V1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
function GUI_V1_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);
global popcount;
global str1
global store
global targetNum
targetNum=1;
store='';
str1='target';
popcount=1;
set(handles.pushbutton2,'Enable','off')
set(handles.pushbutton3,'Enable','off')
set(handles.popupmenu1,'Enable','off')
function varargout = GUI_V1_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;

function pushbutton1_Callback(hObject, eventdata, handles)
t = 1:0.1:100;
Px=get(handles.edit1,'String');
Py=get(handles.edit2,'String');
Pz=get(handles.edit3,'String');
px=str2double(Px);
py=str2double(Py);
pz=str2double(Pz);
Vx=get(handles.edit4,'String');
Vy=get(handles.edit5,'String');
Vz=get(handles.edit6,'String');
vx=str2double(Vx);
vy=str2double(Vy);
vz=str2double(Vz);
Ax=get(handles.edit7,'String');
Ay=get(handles.edit8,'String');
Az=get(handles.edit9,'String');
ax=str2double(Ax);
ay=str2double(Ay);
az=str2double(Az);
x=px+vx.*t+0.5*ax.*t.*t;
y=py+vy.*t+0.5*ay.*t.*t;
z=pz+vz.*t+0.5*az.*t.*t;
grid on;
axes(handles.axes1);
plot3(x,y,z);
title('Objective)')
set(handles.pushbutton1,'Enable','off');
set(handles.pushbutton2,'Enable','on');
set(handles.pushbutton3,'Enable','on');
set(handles.popupmenu1,'Enable','on');
global targetNum
targetNum=targetNum+1;
figure('name', 'Objective')
plot3(x,y,z)
%set(figure,'Tag','axes');
%set(h,'visible','off');
saveas(gcf,'Objective');
close('Objective');
hold on
grid on;
global popcount;
global str1
global store
str2=num2str(popcount);
sc=[str1 str2];
str3=sc;
str4='|';
sc=[str3 str4];
sc=[store sc];
store=sc;
set(handles.popupmenu1,'string',sc);
popcount=popcount+1;



function edit1_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit2_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit2_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit3_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit4_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit5_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit5_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit6_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit7_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit7_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit8_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit8_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit9_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit9_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function pushbutton2_Callback(hObject, eventdata, handles)
t = 1:0.1:100;
Px=get(handles.edit1,'String');
Py=get(handles.edit2,'String');
Pz=get(handles.edit3,'String');
px=str2double(Px);
py=str2double(Py);
pz=str2double(Pz);
Vx=get(handles.edit4,'String');
Vy=get(handles.edit5,'String');
Vz=get(handles.edit6,'String');
vx=str2double(Vx);
vy=str2double(Vy);
vz=str2double(Vz);
Ax=get(handles.edit7,'String');
Ay=get(handles.edit8,'String');
Az=get(handles.edit9,'String');
ax=str2double(Ax);
ay=str2double(Ay);
az=str2double(Az);
x=px+vx.*t+0.5.*ax.*t.*t;
y=py+vy.*t+0.5.*ay.*t.*t;
z=pz+vz.*t+0.5.*az.*t.*t;
grid on;
axes(handles.axes1);
hold on;
plot3(x,y,z);
title('Objective)')
grid on;
global targetNum
targetNum=targetNum+1;
open('Objective.fig')
hold on;
plot3(x,y,z)
grid on;
saveas(gcf,'Objective');
close('Objective');
global popcount;
global str1
global store
str2=num2str(popcount);
sc=[str1 str2];
str3=sc;
str4='|';
sc=[str3 str4];
sc=[store sc];
store=sc;
set(handles.popupmenu1,'string',sc);
popcount=popcount+1;
function pushbutton3_Callback(hObject, eventdata, handles)
cla(handles.axes1);
cla(handles.axes2);
global popcount;
global str1
global store
global targetNum
targetNum=0;
store='';
str1='target';
popcount=1;
set(handles.popupmenu1,'String','Pop-up menu')
set(handles.pushbutton1,'Enable','on');
set(handles.pushbutton2,'Enable','off');
set(handles.pushbutton3,'Enable','off');
set(handles.popupmenu1,'Enable','off');
set(handles.popupmenu1,'Value',1)
delete Objective.fig
function popupmenu1_Callback(hObject, eventdata, handles)
global popcount
contents = cellstr(get(hObject,'String')) ;
str=contents{get(hObject,'Value')};
num=str2num(str(7:7));
a=popcount-num;
open('Objective.fig')
obj = get(gca,'children');
x=get(obj(a), 'xdata');
y=get(obj(a), 'ydata');
z=get(obj(a), 'zdata');
close('Objective');
axes(handles.axes2);
plot3(x,y,z);
grid on;
function popupmenu1_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
