function varargout = GUI_V2(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @GUI_V2_OpeningFcn, ...
    'gui_OutputFcn',  @GUI_V2_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin &&ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
function GUI_V2_OpeningFcn(hObject, eventdata, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);
global TargetNum
TargetNum=1;
global PlotTog
PlotTog=0;
global PlotChoice
PlotChoice='x vs t|y vs t|z vs t|R vs t|��vs t|�� vs t';
set(handles.popupmenu2,'String',PlotChoice)
global popcount;
global str1
global store
store='';
str1='Target';
popcount=1;
set(handles.popupmenu1,'string','None')
set(handles.popupmenu2,'Enable','off')
set(handles.popupmenu3,'Enable','off')
set(handles.popupmenu3,'String','dB|linear');
set(handles.popupmenu1,'Enable','off');
set(handles.edit21,'Enable','off')
set(handles.pushbutton6,'Enable','off')
set(handles.edit26,'Enable','off')
global resolution;resolution=1;
global tGlobal;tGlobal=0;
global snr;snr=0;
global snrType;snrType=0;
global totalTime;totalTime=0;
global range; range=0;global NoiseCho
NoiseCho=1;global ViewType;ViewType=2;
function varargout = GUI_V2_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;
function edit1_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','1')
end
function edit1_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit2_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit2_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit3_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit3_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit4_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit4_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit5_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit5_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit6_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit6_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit7_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit7_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit8_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit8_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit9_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit9_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit10_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit10_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit11_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit11_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit12_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit12_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit13_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit13_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit14_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit14_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit15_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit15_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit16_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit16_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit17_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit17_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit18_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit18_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit19_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit19_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit20_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit20_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit21_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit21_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit22_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit22_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit23_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit23_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function pushbutton1_Callback(hObject, eventdata, handles)
global range
range=str2double(get(handles.edit2,'String'));
set(handles.edit2,'Enable','off');
set(handles.pushbutton1,'Enable','off');
function pushbutton2_Callback(hObject, eventdata, handles)
PositionOfX=str2double(get(handles.edit3,'String'));
PositionOfY=str2double(get(handles.edit4,'String'));
PositionOfZ=str2double(get(handles.edit5,'String'));
VelocityOfX=str2double(get(handles.edit6,'String'));
VelocityOfY=str2double(get(handles.edit7,'String'));
VelocityOfZ=str2double(get(handles.edit8,'String'));
AccOfX=str2double(get(handles.edit9,'String'));
AccOfY=str2double(get(handles.edit10,'String'));
AccOfZ=str2double(get(handles.edit11,'String'));
StartTime=str2double(get(handles.edit22,'String'));
EndTime=str2double(get(handles.edit25,'String'));
set(handles.pushbutton2,'Enable','off');
global Target Times TargetNum totalTime resolution
n=TargetNum;
Target{n}(1)=PositionOfX;
Target{n}(2)=PositionOfY;
Target{n}(3)=PositionOfZ;
Target{n}(4)=VelocityOfX;
Target{n}(5)=VelocityOfY;
Target{n}(6)=VelocityOfZ;
Target{n}(7)=AccOfX;
Target{n}(8)=AccOfY;
Target{n}(9)=AccOfZ;
Target{n}(10)=StartTime;
Target{n}(11)=EndTime;
Target{n}(12)=0;
Target{n}(13)=0;
Times{n}=StartTime-StartTime:resolution:EndTime-StartTime;
totalTime=EndTime;
t=Times{n};
global x y z snx sny snz
x{n}=Target{n}(1)+Target{n}(4).*t+0.5.*Target{n}(7).*t.*t;
y{n}=Target{n}(2)+Target{n}(5).*t+0.5.*Target{n}(8).*t.*t;
z{n}=Target{n}(3)+Target{n}(6).*t+0.5.*Target{n}(9).*t.*t;
sny{n}=Target{n}(2)+Target{n}(5).*t+0.5.*Target{n}(8).*t.*t+Target{n}(13).*randn(size(t))+Target{n}(12);
snz{n}=Target{n}(3)+Target{n}(6).*t+0.5.*Target{n}(9).*t.*t+Target{n}(13).*randn(size(t))+Target{n}(12);
global popcount str1 store
str2=num2str(popcount);
sc=[str1 str2];
store=sc;
set(handles.popupmenu1,'string',sc);
set(handles.pushbutton6,'Enable','on');
function pushbutton3_Callback(hObject, eventdata, handles
global TargetNum
global totalTime
TargetNum=TargetNum+1;
n=TargetNum;
PositionOfX=str2double(get(handles.edit12,'String'));
PositionOfY=str2double(get(handles.edit13,'String'));
PositionOfZ=str2double(get(handles.edit14,'String'));
VelocityOfX=str2double(get(handles.edit15,'String'));
VelocityOfY=str2double(get(handles.edit16,'String'));
VelocityOfZ=str2double(get(handles.edit17,'String'));
AccOfX=str2double(get(handles.edit18,'String'));
AccOfY=str2double(get(handles.edit19,'String'));
AccOfZ=str2double(get(handles.edit20,'String'));
StartTime=str2double(get(handles.edit23,'String'));
EndTime=str2double(get(handles.edit24,'String'));
if EndTime>totalTime
    totalTime=EndTime;
end
global Target resolution Times
Target{n}(1)=PositionOfX;
Target{n}(2)=PositionOfY;
Target{n}(3)=PositionOfZ;
Target{n}(4)=VelocityOfX;
Target{n}(5)=VelocityOfY;
Target{n}(6)=VelocityOfZ;
Target{n}(7)=AccOfX;
Target{n}(8)=AccOfY;
Target{n}(9)=AccOfZ;
Target{n}(10)=StartTime;
Target{n}(11)=EndTime;
Target{n}(12)=0;
Target{n}(13)=0;
Times{n}=StartTime-StartTime:resolution:EndTime-StartTime;
t=Times{n};
global x y z
x{n}=Target{n}(1)+Target{n}(4).*t+0.5.*Target{n}(7).*t.*t;
y{n}=Target{n}(2)+Target{n}(5).*t+0.5.*Target{n}(8).*t.*t;
z{n}=Target{n}(3)+Target{n}(6).*t+0.5.*Target{n}(9).*t.*t;
global snx sny snz
%snx{n}=x{n}+ Target{n}(13).*randn(size(t))+Target{n}(12);
sny{n}=y{n}+Target{n}(13).*randn(size(t))+Target{n}(12);
snz{n}=z{n}+Target{n}(13).*randn(size(t))+Target{n}(12);
global popcount;
global str1
global store
popcount=popcount+1;
str2=num2str(popcount);
sc=[str1 str2];
str3=sc;
str4='|';
sc=[str4 str3];
sc=[store sc];
store=sc;
set(handles.popupmenu1,'string',sc);
function radiobutton1_Callback(hObject, eventdata, handles)
h=get(hObject,'Value');
if h==0
else
    set(handles.radiobutton2,'Value',0);
    set(handles.popupmenu1,'Enable','on');
end
function radiobutton2_Callback(hObject, eventdata, handles)
global ViewType NoiseCho
ViewType=1;
h=get(hObject,'Value');
if h==0
else
    set(handles.radiobutton1,'Value',0);
end
global Target TargetNum resolution totalTime x y z range
hold off
cla(handles.axes1);
axes(handles.axes1)
xlabel('x/m');
ylabel('y/m')
zlabel('z/m')
axis([0 range -range range -range range]);
hold on
t=1:resolution:totalTime;
if NoiseCho==1
    for m=1:numel(t)
        set(handles.edit26,'String',m);
        for n=1:TargetNum
            if m-Target{n}(10)==Target{n}(11)-Target{n}(10)         
                sc=['Target ' num2str(n)];
                text(x{n}(round(m-Target{n}(10))),y{n}(round(m-Target{n}(10))),z{n}(round(m-Target{n}(10))),sc);
            end         
            if m-Target{n}(10)<Target{n}(11)-Target{n}(10)
                if NoiseCho~=1||ViewType~=1
                    break;
                end
                plot3(x{n}(1:round(m-Target{n}(10))),y{n}(1:round(m-Target{n}(10))),z{n}(1:round(m-Target{n}(10))),'-r');
            end            
            grid on;
            drawnow
        end
    end
end
global sny snz
if NoiseCho==2
    for m=1:numel(t)
        set(handles.edit26,'String',m);
        for n=1:TargetNum
            if m-Target{n}(10)==Target{n}(11)-Target{n}(10)               
                sc=['Target ' num2str(n)];
                text(x{n}(round(m-Target{n}(10))),y{n}(round(m-Target{n}(10))),z{n}(round(m-Target{n}(10))),sc);
            end            
            if m-Target{n}(10)<Target{n}(11)-Target{n}(10)
                if NoiseCho~=2||ViewType~=1
                    break;
                end
                plot3(x{n}(1:round(m-Target{n}(10))),sny{n}(1:round(m-Target{n}(10))),snz{n}(1:round(m-Target{n}(10))),'-b');
            end            
            grid on;
            drawnow
        end
    end
end
if NoiseCho==3
    for m=1:numel(t)
        set(handles.edit26,'String',m);
        for n=1:TargetNum            
            if m-Target{n}(10)==Target{n}(11)-Target{n}(10)                
                sc=['Target ' num2str(n)];
                text(x{n}(round(m-Target{n}(10))),y{n}(round(m-Target{n}(10))),z{n}(round(m-Target{n}(10))),sc);
            end           
            if m-Target{n}(10)<Target{n}(11)-Target{n}(10)
                if NoiseCho~=3||ViewType~=1
                    break;
                end
                plot3(x{n}(1:round(m-Target{n}(10))),y{n}(1:round(m-Target{n}(10))),z{n}(1:round(m-Target{n}(10))),'-r');
                plot3(x{n}(1:round(m-Target{n}(10))),sny{n}(1:round(m-Target{n}(10))),snz{n}(1:round(m-Target{n}(10))),'-b');
            end           
            grid on;
            drawnow
        end
    end
end
function pushbutton5_Callback(hObject, eventdata, handles)
global snr
snr=str2double(get(handles.edit21,'String'));
popupmenu2()
function popupmenu1_Callback(hObject, eventdata, handles)
global popcount
contents = cellstr(get(hObject,'String')) ;
str=contents{get(hObject,'Value')};
len=length(str);
popcount=str2num(str(7:len));
set(handles.popupmenu2,'Enable','on');
function popupmenu1_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function popupmenu2_Callback(hObject, eventdata, handles)
popupmenu2()
function popupmenu2_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function checkbox1_Callback(hObject, eventdata, handles)
h=get(hObject,'Value');
global snrType
if h==0
    set(handles.edit21,'Enable','off')
    set(handles.popupmenu3,'Enable','off');
    snrType=0;
    
else
    set(handles.edit21,'Enable','on')
    set(handles.popupmenu3,'Enable','on');
end
function popupmenu3_Callback(hObject, eventdata, handles)
global snrType
contents = cellstr(get(hObject,'String')) ;
str=contents{get(hObject,'Value')};
switch str
    case 'dB'
        snrType=1;
    case 'linear'
        snrType=2;
end
function popupmenu3_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit24_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit24_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function edit25_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit25_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function pushbutton6_Callback(hObject, eventdata, handles)
listbox
function edit26_Callback(hObject, eventdata, handles)
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end
function edit26_CreateFcn(hObject, eventdata, handles)
if ispc || isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
function pushbutton7_Callback(hObject, eventdata, handles)
global ViewType
ViewType=3;
hold off
cla(handles.axes1)
xlabel('z/m');
ylabel('y/m');
global Target TargetNum resolution totalTime x y z range NoiseCho snz sny snx
axis([-range range -range range]);
hold on
t=1:resolution:totalTime;
if NoiseCho==1
    for m=1:numel(t)
        for n=1:TargetNum
            if m-Target{n}(10)==Target{n}(11)-Target{n}(10)              
                sc=['Target ' num2str(n)];
                text(y{n}(round(m-Target{n}(10))),z{n}(round(m-Target{n}(10))),sc);
            end
            if m-Target{n}(10)<Target{n}(11)-Target{n}(10)
                if NoiseCho~=1||ViewType~=3
                    break;
                end
                plot(y{n}(1:round(m-Target{n}(10))),z{n}(1:round(m-Target{n}(10))),'-r');
            end
            grid on;
            drawnow
        end
    end
end
if NoiseCho==2
    for m=1:numel(t)
        set(handles.edit26,'String',m);
        for n=1:TargetNum            
            if m-Target{n}(10)==Target{n}(11)-Target{n}(10)               
                sc=['Target ' num2str(n)];
                text(x{n}(round(m-Target{n}(10))),y{n}(round(m-Target{n}(10))),z{n}(round(m-Target{n}(10))),sc);
            end
            if m-Target{n}(10)<Target{n}(11)-Target{n}(10)
                if NoiseCho~=2||ViewType~=3
                    break;
                end
                plot(sny{n}(1:round(m-Target{n}(10))),snz{n}(1:round(m-Target{n}(10))),'-b');
            end            
            grid on;
            drawnow
        end
    end
end
if NoiseCho==3
    for m=1:numel(t)
        set(handles.edit26,'String',m);
        for n=1:TargetNum            
            if m-Target{n}(10)==Target{n}(11)-Target{n}(10)                
                sc=['Target ' num2str(n)];
                text(x{n}(round(m-Target{n}(10))),y{n}(round(m-Target{n}(10))),z{n}(round(m-Target{n}(10))),sc);
            end            
            if m-Target{n}(10)<Target{n}(11)-Target{n}(10)
                if NoiseCho~=3||ViewType~=3
                    break;
                end
                plot(y{n}(1:round(m-Target{n}(10))),z{n}(1:round(m-Target{n}(10))),'-r');
                plot(sny{n}(1:round(m-Target{n}(10))),snz{n}(1:round(m-Target{n}(10))),'-b');
            end            
            grid on;
            drawnow
        end
    end
end
function pushbutton8_Callback(hObject, eventdata, handles)
global snx sny snz Times NoiseCho
global ViewType
ViewType=4;
hold off
cla(handles.axes1)
xlabel('x/m');
ylabel('z/m');
global Target TargetNum resolution totalTime x y z range
axis([0 range -range range]);
hold on
t=1:resolution:totalTime;
if NoiseCho==1
    for m=1:numel(t)
        for n=1:TargetNum
            if m-Target{n}(10)==Target{n}(11)-Target{n}(10)                
                sc=['Target ' num2str(n)];
                text(x{n}(round(m-Target{n}(10))),z{n}(round(m-Target{n}(10))),sc);
            end
            if m-Target{n}(10)<Target{n}(11)-Target{n}(10)
                if NoiseCho~=1||ViewType~=4
                    break;
                end
                plot(x{n}(1:round(m-Target{n}(10))),z{n}(1:round(m-Target{n}(10))),'-r');
            end
            grid on;
            drawnow
        end
    end
end
if NoiseCho==2
    for m=1:numel(t)
        set(handles.edit26,'String',m);
        for n=1:TargetNum          
            if m-Target{n}(10)==Target{n}(11)-Target{n}(10)               
                sc=['Target ' num2str(n)];
                text(x{n}(round(m-Target{n}(10))),y{n}(round(m-Target{n}(10))),z{n}(round(m-Target{n}(10))),sc);
            end           
            if m-Target{n}(10)<Target{n}(11)-Target{n}(10)
                if NoiseCho~=2||ViewType~=4
                    break;
                end
                plot(x{n}(1:round(m-Target{n}(10))),snz{n}(1:round(m-Target{n}(10))),'-b');
            end           
            grid on;
            drawnow
        end
    end
end
if NoiseCho==3
    for m=1:numel(t)
        set(handles.edit26,'String',m);
        for n=1:TargetNum          
            if m-Target{n}(10)==Target{n}(11)-Target{n}(10)              
                sc=['Target ' num2str(n)];
                text(x{n}(round(m-Target{n}(10))),y{n}(round(m-Target{n}(10))),z{n}(round(m-Target{n}(10))),sc);
            end          
            if m-Target{n}(10)<Target{n}(11)-Target{n}(10)
                if NoiseCho~=3||ViewType~=4
                    break;
                end
                plot(x{n}(1:round(m-Target{n}(10))),z{n}(1:round(m-Target{n}(10))),'-r');
                plot(x{n}(1:round(m-Target{n}(10))),snz{n}(1:round(m-Target{n}(10))),'-b');
            end          
            grid on;
            drawnow
        end
    end
end
function pushbutton9_Callback(hObject, eventdata, handles)
radiobutton2_Callback(hObject, eventdata, handles)
function pushbutton10_Callback(hObject, eventdata, handles)
global ViewType
ViewType=2;
hold off
cla(handles.axes1)
xlabel('x/m');
ylabel('y/m');
global Target TargetNum resolution totalTime x y z range sny NoiseCho
axis([0 range -range range]);
hold on
t=1:resolution:totalTime;
if NoiseCho==1
    for m=1:numel(t)
        for n=1:TargetNum
            if m-Target{n}(10)==Target{n}(11)-Target{n}(10)
                
                sc=['Target ' num2str(n)];
                text(x{n}(round(m-Target{n}(10))),y{n}(round(m-Target{n}(10))),z{n}(round(m-Target{n}(10))),sc);
            end
            if m-Target{n}(10)<Target{n}(11)-Target{n}(10)
                if NoiseCho~=1||ViewType~=2
                    break;
                end
                %  plot(x{n}(1:round(m-Target{n}(10))),y{n}(1:round(m-Target{n}(10))),'-r');
                plot(x{n}(1:round(m-Target{n}(10))),y{n}(1:round(m-Target{n}(10))),'-r');
            end
            grid on;
            drawnow
        end
    end
end
if NoiseCho==2
    for m=1:numel(t)
        set(handles.edit26,'String',m);
        for n=1:TargetNum
            
            if m-Target{n}(10)==Target{n}(11)-Target{n}(10)
                
                sc=['Target ' num2str(n)];
                text(x{n}(round(m-Target{n}(10))),y{n}(round(m-Target{n}(10))),z{n}(round(m-Target{n}(10))),sc);
            end
            
            if m-Target{n}(10)<Target{n}(11)-Target{n}(10)
                if NoiseCho~=2||ViewType~=2
                    break;
                end
                plot(x{n}(1:round(m-Target{n}(10))),sny{n}(1:round(m-Target{n}(10))),'-b');
            end
            
            grid on;
            drawnow
        end
    end
end
if NoiseCho==3
    for m=1:numel(t)
        set(handles.edit26,'String',m);
        for n=1:TargetNum
            
            if m-Target{n}(10)==Target{n}(11)-Target{n}(10)
                
                sc=['Target ' num2str(n)];
                text(x{n}(round(m-Target{n}(10))),y{n}(round(m-Target{n}(10))),z{n}(round(m-Target{n}(10))),sc);
            end
            
            if m-Target{n}(10)<Target{n}(11)-Target{n}(10)
                if NoiseCho~=3||ViewType~=2
                    break;
                end
                plot(x{n}(1:round(m-Target{n}(10))),y{n}(1:round(m-Target{n}(10))),'-r');
                plot(x{n}(1:round(m-Target{n}(10))),sny{n}(1:round(m-Target{n}(10))),'-b');
            end
            
            grid on;
            drawnow
        end
    end
end
function pushbutton11_Callback(hObject, eventdata, handles)
global NoiseCho ViewType
NoiseCho=2;
if ViewType==1
    radiobutton2_Callback(hObject, eventdata, handles)
else if ViewType==2
        pushbutton10_Callback(hObject, eventdata, handles)
    else if ViewType==3
            pushbutton7_Callback(hObject, eventdata, handles)
        else if ViewType==4
                pushbutton8_Callback(hObject, eventdata, handles)
            end
        end
    end
end
function pushbutton12_Callback(hObject, eventdata, handles)
global NoiseCho ViewType
NoiseCho=1;
if ViewType==1
    radiobutton2_Callback(hObject, eventdata, handles)
else if ViewType==2
        pushbutton10_Callback(hObject, eventdata, handles)
    else if ViewType==3
            pushbutton7_Callback(hObject, eventdata, handles)
        else if ViewType==4
                pushbutton8_Callback(hObject, eventdata, handles)
            end
        end
    end
end
function pushbutton13_Callback(hObject, eventdata, handles)global NoiseCho ViewType
NoiseCho=3;
if ViewType==1
    radiobutton2_Callback(hObject, eventdata, handles)
else if ViewType==2
        pushbutton10_Callback(hObject, eventdata, handles)
    else if ViewType==3
            pushbutton7_Callback(hObject, eventdata, handles)
        else if ViewType==4
                pushbutton8_Callback(hObject, eventdata, handles)
            end
        end
    end
end
