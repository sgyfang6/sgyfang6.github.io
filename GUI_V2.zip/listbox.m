function varargout = listbox(varargin)
% LISTBOX MATLAB code for listbox.fig
%      LISTBOX, by itself, creates a new LISTBOX or raises the existing
%      singleton*.
%
%      H = LISTBOX returns the handle to a new LISTBOX or the handle to
%      the existing singleton*.
%
%      LISTBOX('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LISTBOX.M with the given input arguments.
%
%      LISTBOX('Property','Value',...) creates a new LISTBOX or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before listbox_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to listbox_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help listbox

% Last Modified by GUIDE v2.5 30-Nov-2017 19:19:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @listbox_OpeningFcn, ...
    'gui_OutputFcn',  @listbox_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before listbox is made visible.
function listbox_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to listbox (see VARARGIN)

% Choose default command line output for listbox
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
set(handles.pushbutton1,'Enable','Off');
set(handles.listbox1,'String','None');
set(handles.listbox1,'Visible','on');
set(handles.listbox2,'String','None');
set(handles.listbox2,'Visible','Off');
set(handles.listbox3,'Visible','Off');
set(handles.pushbutton3,'Visible','Off');
set(handles.pushbutton4,'Visible','Off');
set(handles.pushbutton4,'Enable','Off');
global store
set(handles.listbox1,'string',store);
global listcount
listcount=1;

% UIWAIT makes listbox wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = listbox_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1
global listcount
contents = cellstr(get(hObject,'String')) ;
str=contents{get(hObject,'Value')};
len=length(str);
listcount=str2num(str(7:len));

% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.listbox2,'Visible','off');
set(handles.listbox1,'Visible','on');
set(handles.pushbutton1,'Enable','off');
set(handles.pushbutton2,'Visible','on');
set(handles.pushbutton2,'Enable','on');
set(handles.pushbutton4,'Visible','off');


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.listbox1,'Visible','off');
set(handles.listbox2,'Visible','on');
set(handles.pushbutton2,'Visible','off');

set(handles.pushbutton1,'Enable','on');

global Target listcount
str1=num2str(listcount);
str='Target';
str=[str str1];
str2='|';
str=[str str2];
str=[str ' x = ' num2str(Target{listcount}(1)) str2];
str=[str ' y = ' num2str(Target{listcount}(2)) str2];
str=[str ' z = ' num2str(Target{listcount}(3)) str2];
str=[str 'Vx = ' num2str(Target{listcount}(4)) str2];
str=[str 'Vy = ' num2str(Target{listcount}(5)) str2];
str=[str 'Vz = ' num2str(Target{listcount}(6)) str2];
str=[str 'ax = ' num2str(Target{listcount}(7)) str2];
str=[str 'ay = ' num2str(Target{listcount}(8)) str2];
str=[str 'az = ' num2str(Target{listcount}(9)) str2];
str=[str 'TS = ' num2str(Target{listcount}(10)) str2];
str=[str 'TE = ' num2str(Target{listcount}(11)) str2];
str=[str 'Noise Configuration' str2];
str=[str '�� = ' num2str(Target{listcount}(12)) str2];
str=[str '�� = ' num2str(Target{listcount}(13)) str2];
str=[str '��^2 = ' num2str(Target{listcount}(13)^2)];
set(handles.listbox2,'String',str);

% --- Executes on selection change in listbox2.
function listbox2_Callback(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox2
contents = cellstr(get(hObject,'String')) ;
str=contents{get(hObject,'Value')};
if strcmp(str,'Noise Configuration')==1
    %set(handles.pushbutton2,'Visible','Off');
    set(handles.pushbutton4,'Visible','On');
    set(handles.pushbutton4,'Enable','on');
else
    set(handles.pushbutton4,'Visible','Off');
end

% --- Executes during object creation, after setting all properties.
function listbox2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.pushbutton3,'Visible','Off');
set(handles.pushbutton1,'Visible','On');
set(handles.pushbutton4,'Visible','Off');
set(handles.pushbutton2,'Visible','Off');
set(handles.listbox3,'Visible','Off');
set(handles.listbox2,'Visible','On');

global Target listcount
str1=num2str(listcount);
str='Target';
str=[str str1];
str2='|';
str=[str str2];
str=[str ' x = ' num2str(Target{listcount}(1)) str2];
str=[str ' y = ' num2str(Target{listcount}(2)) str2];
str=[str ' z = ' num2str(Target{listcount}(3)) str2];
str=[str 'Vx = ' num2str(Target{listcount}(4)) str2];
str=[str 'Vy = ' num2str(Target{listcount}(5)) str2];
str=[str 'Vz = ' num2str(Target{listcount}(6)) str2];
str=[str 'ax = ' num2str(Target{listcount}(7)) str2];
str=[str 'ay = ' num2str(Target{listcount}(8)) str2];
str=[str 'az = ' num2str(Target{listcount}(9)) str2];
str=[str 'TS = ' num2str(Target{listcount}(10)) str2];
str=[str 'TE = ' num2str(Target{listcount}(11)) str2];
str=[str 'Noise Configuration' str2];
str=[str '�� = ' num2str(Target{listcount}(12)) str2];
str=[str '�� = ' num2str(Target{listcount}(13)) str2];
str=[str '��^2 = ' num2str(Target{listcount}(13)^2)];
set(handles.listbox2,'String',str);

% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Target listcount
set(handles.listbox2,'Visible','Off');
set(handles.listbox3,'Visible','On');
set(handles.pushbutton4,'Visible','Off');
set(handles.pushbutton3,'Visible','On');
str2='|';
str=['�� = ' num2str(Target{listcount}(12)) str2];
str=[str '�� = ' num2str(Target{listcount}(13)) str2];
str=[str '��^2 = ' num2str(Target{listcount}(13)^2)];
set(handles.listbox3,'String',str);

% --- Executes on selection change in listbox3.
function listbox3_Callback(hObject, eventdata, handles)
% hObject    handle to listbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox3 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox3
global Target listcount
global  sny snz Times x y z
contents = cellstr(get(hObject,'String')) ;
str=contents{get(hObject,'Value')};
if strcmp(str(1:3),'�� =')==1
    prompt='\mu  ';
    name='Value Configuration';
    defaultans={num2str((Target{listcount}(12)))};
    options.Interpreter = 'tex';
    value=inputdlg(prompt,name,[1 40],defaultans,options);
    Target{listcount}(12)=str2double(cell2mat(value(1)));
    str2='|';
    str=['�� = ' num2str(Target{listcount}(12)) str2];
    str=[str '�� = ' num2str(Target{listcount}(13)) str2];
    str=[str '��^2 = ' num2str(Target{listcount}(13)^2)];
    set(handles.listbox3,'String',str);
end
if strcmp(str(1:3),'�� =')==1
    prompt='\sigma  ';
    name='Value Configuration';
    defaultans={num2str((Target{listcount}(13)))};
    options.Interpreter = 'tex';
    value=inputdlg(prompt,name,[1 40],defaultans,options);
    Target{listcount}(13)=str2double(cell2mat(value));
    
    str2='|';
    str=['�� = ' num2str(Target{listcount}(12)) str2];
    str=[str '�� = ' num2str(Target{listcount}(13)) str2];
    str=[str '��^2 = ' num2str(Target{listcount}(13)^2)];
    set(handles.listbox3,'String',str);
end


sny{listcount}=y{listcount}+Target{listcount}(13).*randn(size(Times{listcount}))+Target{listcount}(12);
snz{listcount}=z{listcount}+Target{listcount}(13).*randn(size(Times{listcount}))+Target{listcount}(12);
% --- Executes during object creation, after setting all properties.
function listbox3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
