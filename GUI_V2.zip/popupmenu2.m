global popcount Target snrType snr resolution
contents = cellstr(get(hObject,'String')) ;
str=contents{get(hObject,'Value')};
t=0:resolution:Target{popcount}(11);
switch str
    case 'x vs t'
        if snrType==0
            x=Target{popcount}(1)+Target{popcount}(4).*t+0.5.*Target{popcount}(7).*t.*t;
        elseif snrType==1
            x=Target{popcount}(1)+Target{popcount}(4).*t+0.5.*Target{popcount}(7).*t.*t;
            x=awgn(x,snr,'measured','dB');
        elseif snrType==2
            x=Target{popcount}(1)+Target{popcount}(4).*t+0.5.*Target{popcount}(7).*t.*t;
            x=awgn(x,snr,'measured','linear');
        end
        grid on
        comet(handles.axes1,x);
        xlabel('t/s');ylabel('x/m');
    case 'y vs t'
        if snrType==0
            y=Target{popcount}(2)+Target{popcount}(5).*t+0.5.*Target{popcount}(8).*t.*t;
            
        elseif snrType==1
            y=Target{popcount}(2)+Target{popcount}(5).*t+0.5.*Target{popcount}(8).*t.*t;
            y=awgn(y,snr,'measured','dB');
        elseif snrType==2
            y=Target{popcount}(2)+Target{popcount}(5).*t+0.5.*Target{popcount}(8).*t.*t;
            y=awgn(y,snr,'measured','linear');
        end
        grid on
        xlabel('t/s');ylabel('y/m');
        comet(handles.axes1,y);
    case 'z vs t'
        if snrType==0
            z=Target{popcount}(3)+Target{popcount}(6).*t+0.5.*Target{popcount}(9).*t.*t;
        elseif snrType==1
            z=Target{popcount}(3)+Target{popcount}(6).*t+0.5.*Target{popcount}(9).*t.*t;
            z=awgn(z,snr,'measured','dB');
        elseif snrType==2
            z=Target{popcount}(3)+Target{popcount}(6).*t+0.5.*Target{popcount}(9).*t.*t;
            z=awgn(z,snr,'measured','linear');
        end
        
        grid on
        xlabel('t/s');ylabel('z/m');
        comet(handles.axes1,z);
    case 'R vs t'
        x=Target{popcount}(1)+Target{popcount}(4).*t+0.5.*Target{popcount}(7).*t.*t;
        y=Target{popcount}(2)+Target{popcount}(5).*t+0.5.*Target{popcount}(8).*t.*t;
        z=Target{popcount}(3)+Target{popcount}(6).*t+0.5.*Target{popcount}(9).*t.*t;
        r=sqrt(x.^2+y.^2+z.^2);
        if snrType==0
        elseif snrType==1
            r=awgn(r,snr,'measured','dB');
        elseif snrType==2
            r=awgn(r,snr,'measured','linear');
        end
        
        grid on
        xlabel('t/s');ylabel('R/m');
        comet(handles.axes1,r);
        
        
    case '��vs t'
        x=Target{popcount}(1)+Target{popcount}(4).*t+0.5.*Target{popcount}(7).*t.*t;
        y=Target{popcount}(2)+Target{popcount}(5).*t+0.5.*Target{popcount}(8).*t.*t;
        theta=atan(y./x)./pi;
        if snrType==0
        elseif snrType==1
            theta=awgn(theta,snr,'measured','dB');
        elseif snrType==2
            theta=awgn(theta,snr,'measured','linear');  
        end
        grid on
        xlabel('t/s');ylabel('��/m');
        comet(handles.axes1,theta);
    case '�� vs t'
        x=Target{popcount}(1)+Target{popcount}(4).*t+0.5.*Target{popcount}(7).*t.*t;
        y=Target{popcount}(2)+Target{popcount}(5).*t+0.5.*Target{popcount}(8).*t.*t;
        z=Target{popcount}(3)+Target{popcount}(6).*t+0.5.*Target{popcount}(9).*t.*t;
        r=sqrt(x.^2+y.^2+z.^2);
        phi=asin(z./r)./pi;
        if snrType==0
        elseif snrType==1
            phi=awgn(phi,snr,'measured','dB');
        elseif snrType==2
           phi= awgn(phi,snr,'measured','linear');
        end
        grid on
        xlabel('t/s');ylabel('��/m');
        comet(handles.axes1,phi);
end