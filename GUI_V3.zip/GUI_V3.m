function varargout = GUI_V3(varargin)
% GUI_V3 MATLAB code for GUI_V3.fig
%      GUI_V3, by itself, creates a new GUI_V3 or raises the existing
%      singleton*.
%
%      H = GUI_V3 returns the handle to a new GUI_V3 or the handle to
%      the existing singleton*.
%
%      GUI_V3('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI_V3.M with the given input arguments.
%
%      GUI_V3('Property','Value',...) creates a new GUI_V3 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI_V3_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI_V3_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI_V3

% Last Modified by GUIDE v2.5 11-Mar-2018 22:57:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @GUI_V3_OpeningFcn, ...
    'gui_OutputFcn',  @GUI_V3_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI_V3 is made visible.
function GUI_V3_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI_V3 (see VARARGIN)

% Choose default command line output for GUI_V3
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GUI_V3 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


set(handles.edit18,'Enable','off')
set(handles.edit19,'Enable','off')
set(handles.edit28,'Enable','off')
set(handles.pushbutton3,'visible','off')
set(handles.pushbutton4,'visible','off')
set(handles.pushbutton7,'visible','off')
set(handles.pushbutton6,'enable','off')
set(handles.edit20,'enable','off')
set(handles.edit21,'enable','off')
set(handles.edit22,'enable','off')
set(handles.popupmenu1,'enable','off')
set(handles.popupmenu1,'string','dB|Linear')
set(handles.checkbox4,'enable','off')
set(handles.checkbox5,'enable','off')
set(handles.checkbox6,'enable','off')
set(handles.popupmenu2,'visible','off');
set(handles.text44,'visible','off');

global TargetNum
TargetNum=0;

global resolution
resolution=1;

global range
range=0;

global totalTime
totalTime=0;
global checkCho
checkCho=0;

global mu
mu=0;
global sigma
sigma=0;
global snr
snr=0;
global snrType
snrType=1;

global RMS NofClutter defaultans clutterchoice
clutterchoice=0;
RMS=0;
NofClutter=0;
defaultans={};
string='0';
defaultans(1,1)={string};
defaultans(1,2)={string};


% --- Outputs from this function are returned to the command line.
function varargout = GUI_V3_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','1')
end


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global resolution range
resolution=str2double(get(handles.edit1,'String'));
range=str2double(get(handles.edit2,'String'));
set(handles.pushbutton1,'enable','off')
set(handles.edit1,'enable','off');
set(handles.edit2,'enable','off');


function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit17_Callback(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit17 as text
%        str2double(get(hObject,'String')) returns contents of edit17 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1
global Name TargetNum Target selid
sel=get(gcf,'selectiontype');
if strcmp(sel,'normal')
    contents = cellstr(get(hObject,'String')) ;
    str=contents{get(hObject,'Value')};
    for n=1:TargetNum
        if strcmp(str,Name{n})==1
            selid=n;
            break;
        end
    end
    set(handles.edit18,'String',Target{selid}(1))
    set(handles.edit9,'String',Target{selid}(3))
    set(handles.edit10,'String',Target{selid}(4))
    set(handles.edit11,'String',Target{selid}(5))
    set(handles.edit12,'String',Target{selid}(6))
    set(handles.edit13,'String',Target{selid}(7))
    set(handles.edit14,'String',Target{selid}(8))
    set(handles.edit15,'String',Target{selid}(9))
    set(handles.edit16,'String',Target{selid}(10))
    set(handles.edit17,'String',Target{selid}(11))
    set(handles.edit26,'String',Target{selid}(12))
    set(handles.edit27,'String',Target{selid}(13))
    set(handles.pushbutton7,'visible','on')
    set(handles.pushbutton4,'Visible','on')
    set(handles.pushbutton3,'Visible','off')
    
    
    
end

if strcmp(get(gcf,'selectiontype'),'open')==1
    
    prompt='Please Input Target Name : ';
    name='Rename';
    defaultans={Name{selid}};
    options.Interpreter = 'tex';
    value=inputdlg(prompt,name,[1 40],defaultans,options);
    
    if isempty(value)==1
        
    else
        Name{selid}=cell2mat(value);
    end
    
    NameStr='';
    for a=1:TargetNum-1
        NameStr=[NameStr Name{a}];
        NameStr=[NameStr '|'];
    end
    NameStr=[NameStr Name{TargetNum}];
    set(handles.listbox1,'String',NameStr)
    
end

% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1
global Target resolution totalTime checkCho range TargetNum x y z
global snx sny snz ViewType Name RMS NofClutter clutterchoice
ViewType=1;
hold off
cla(handles.axes1);
axes(handles.axes1)
xlabel('x/m');
ylabel('y/m')
zlabel('z/m')
axis([0 range -range range -range range]);
hold on
t=0:resolution:totalTime;
if get(hObject,'Value')==1
    set(handles.radiobutton3,'Value',0);
    set(handles.radiobutton2,'Value',0);
    set(handles.radiobutton4,'Value',0);
    fp=fopen('OutputData.txt','wt+');
    fprintf(fp,'ID          ');
    fprintf(fp,'t           ');
    fprintf(fp,'x           ');
    fprintf(fp,'y           ');
    fprintf(fp,'z\n');
    
    if checkCho==0
        for m=0:numel(t)
            if clutterchoice==1;
                sigma=str2num(cell2mat(RMS));
                no=str2num(cell2mat(NofClutter));
                xc=raylrnd(sigma,[3,no]);
                h=plot3(xc(1,:),xc(2,:),xc(3,:),'.','MarkerSize',6)
                
                for flag=1:no
                fprintf(fp,'c     ');
                fprintf(fp,'%f    ',m);
                fprintf(fp,'%f    ',xc(1,flag));
                fprintf(fp,'%f    ',xc(2,flag));
                fprintf(fp,'%f\n ',xc(3,flag));
                end
                
            end
            for n=1:TargetNum
                %                 n0=35;
                %                 randgenerate=-range+(2*range)*rand(n,1);
                %                 meansquaredvalue=sum(randgenerate.^2)/n0;
                %                 xc=2*randgenerate/(meansquaredvalue).*exp(-randgenerate.^2/meansquaredvalue);
                %                 randgenerate=-range+(2*range)*rand(n,1);
                %                 meansquaredvalue=sum(randgenerate.^2)/n0;
                %                 yc=2*randgenerate/meansquaredvalue.*exp(-randgenerate.^2/meansquaredvalue);
                %                 randgenerate=-range+(2*range)*rand(n,1);
                %                 meansquaredvalue=sum(randgenerate.^2)/n0;
                %                 zc=2*randgenerate/meansquaredvalue.*exp(-randgenerate.^2/meansquaredvalue);
                %                 plot3(xc,yc,zc,'.');
                
                
                if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                    
                    sc=Name{n};
                    text(x{n}(round((m-Target{n}(12)))/resolution),y{n}(round((m-Target{n}(12)))/resolution),z{n}(round(m-Target{n}(12))),sc);
                end
                
                if round( m-Target{n}(12))<=Target{n}(13)-Target{n}(12)
                    if ViewType~=1
                        break;
                    end
                    hh=plot3(x{n}(1:round((m-Target{n}(12))/resolution)),y{n}(1:round((m-Target{n}(12))/resolution)),z{n}(1:round((m-Target{n}(12))/resolution)),'r','MarkerSize',6);
                    
                    if round( m-Target{n}(12))>  0
                        fprintf(fp,'%d    ',n);
                        fprintf(fp,'%f    ',m);
                        fprintf(fp,'%f    ',x{n}(round((m-Target{n}(12))/resolution)));
                        fprintf(fp,'%f    ',y{n}(round((m-Target{n}(12))/resolution)));
                        fprintf(fp,'%f\n',z{n}(round((m-Target{n}(12))/resolution)));
                        
                    end
                end
                
                grid on;
                
                
                drawnow
                if m==totalTime
                else
                    if clutterchoice==1
                        
                        delete(h);
                    end
                end
                
                
            end
        end
        fclose(fp);
    end
    
    if checkCho==1
        for m=1:numel(t)
            if clutterchoice==1;
                sigma=str2num(cell2mat(RMS));
                no=str2num(cell2mat(NofClutter));
                xc=raylrnd(sigma,[3,no]);
                h=plot3(xc(1,:),xc(2,:),xc(3,:),'.','MarkerSize',6)
                for flag=1:no
                fprintf(fp,'c     ');
                fprintf(fp,'%f    ',m);
                fprintf(fp,'%f    ',xc(1,flag));
                fprintf(fp,'%f    ',xc(2,flag));
                fprintf(fp,'%f\n ',xc(3,flag));
                end
                
            end
            for n=1:TargetNum
                
                if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                    
                    sc=Name{n};
                    text(x{n}(round((m-Target{n}(12)))/resolution),sny{n}(round((m-Target{n}(12)))/resolution),snz{n}(round(m-Target{n}(12))),sc);
                end
                
                if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                    if ViewType~=1
                        break;
                    end
                    plot3(x{n}(1:round((m-Target{n}(12))/resolution)),sny{n}(1:round((m-Target{n}(12))/resolution)),snz{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                    if round( m-Target{n}(12))>0
                        fprintf(fp,'%d    ',n);
                        fprintf(fp,'%f    ',m);
                        fprintf(fp,'%f    ',x{n}(round((m-Target{n}(12))/resolution)));
                        fprintf(fp,'%f    ',y{n}(round((m-Target{n}(12))/resolution)));
                        fprintf(fp,'%f\n',z{n}(round((m-Target{n}(12))/resolution)));
                    end
                end
                
                grid on;
                drawnow
                if m==totalTime
                else
                    if clutterchoice==1
                        
                        delete(h);
                    end
                end
                
            end
        end
        fclose(fp);
    end
    if checkCho==2
        for m=1:numel(t)
            if clutterchoice==1;
                sigma=str2num(cell2mat(RMS));
                no=str2num(cell2mat(NofClutter));
                xc=raylrnd(sigma,[3,no]);
                h=plot3(xc(1,:),xc(2,:),xc(3,:),'.','MarkerSize',6);
                for flag=1:no
                fprintf(fp,'c     ');
                fprintf(fp,'%f    ',m);
                fprintf(fp,'%f    ',xc(1,flag));
                fprintf(fp,'%f    ',xc(2,flag));
                fprintf(fp,'%f\n ',xc(3,flag));
                end
                
            end
            for n=1:TargetNum
                
                if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                    
                    sc=Name{n};
                    text(x{n}(round((m-Target{n}(12)))/resolution),sny{n}(round((m-Target{n}(12)))/resolution),snz{n}(round(m-Target{n}(12))),sc);
                end
                
                if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                    if ViewType~=1
                        break;
                    end
                    plot3(x{n}(1:round(((m-Target{n}(12)))/resolution)),sny{n}(1:round((m-Target{n}(12))/resolution)),snz{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                    if round( m-Target{n}(12))>0
                        fprintf(fp,'%d    ',n);
                        fprintf(fp,'%f    ',m);
                        fprintf(fp,'%f    ',x{n}(round((m-Target{n}(12))/resolution)));
                        fprintf(fp,'%f    ',y{n}(round((m-Target{n}(12))/resolution)));
                        fprintf(fp,'%f\n',z{n}(round((m-Target{n}(12))/resolution)));
                    end
                end
                
                grid on;
                drawnow
                if m==totalTime
                else
                    if clutterchoice==1
                        
                        delete(h);
                    end
                end
                
            end
        end
        fclose(fp);
    end
end
% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2
global Target resolution totalTime checkCho range TargetNum x y z
global snx sny snz ViewType Name RMS NofClutter clutterchoice
ViewType=2;
hold off
cla(handles.axes1);
axes(handles.axes1)
xlabel('x/m');
ylabel('y/m')

axis([0 range -range range]);
hold on
t=0:resolution:totalTime;
if get(hObject,'Value')==1
    set(handles.radiobutton1,'Value',0);
    set(handles.radiobutton3,'Value',0);
    set(handles.radiobutton4,'Value',0);
    
    if checkCho==0
        for m=1:numel(t)
            if clutterchoice==1;
                sigma=str2num(cell2mat(RMS));
                no=str2num(cell2mat(NofClutter));
                xc=raylrnd(sigma,[2,no]);
                h=plot(xc(1,:),xc(2,:),'.','MarkerSize',6);
               
            end
            for n=1:TargetNum
                
                if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                    
                    sc=Name{n};
                    text(x{n}(round((m-Target{n}(12)))/resolution),y{n}(round((m-Target{n}(12)))/resolution),sc);
                end
                
                if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                    if ViewType~=2
                        break;
                    end
                    plot(x{n}(1:round((m-Target{n}(12))/resolution)),y{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                end
                
                grid on;
                drawnow
                if m==totalTime
                else
                    if clutterchoice==1
                        
                        delete(h);
                    end
                end
            end
        end
    end
    if checkCho==1
        for m=1:numel(t)
            if clutterchoice==1;
                sigma=str2num(cell2mat(RMS));
                no=str2num(cell2mat(NofClutter));
                xc=raylrnd(sigma,[2,no]);
                h=plot(xc(1,:),xc(2,:),'.','MarkerSize',6);
                
            end
            for n=1:TargetNum
                
                if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                    
                    sc=Name{n};
                    text(x{n}(round((m-Target{n}(12)))/resolution),y{n}(round((m-Target{n}(12)))/resolution),sc);
                end
                
                if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                    if ViewType~=2
                        break;
                    end
                    plot(x{n}(1:round((m-Target{n}(12))/resolution)),sny{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                end
                
                grid on;
                drawnow
                if m==totalTime
                else
                    if clutterchoice==1
                        
                        delete(h);
                    end
                end
            end
        end
    end
    if checkCho==2
        for m=1:numel(t)
            if clutterchoice==1;
                sigma=str2num(cell2mat(RMS));
                no=str2num(cell2mat(NofClutter));
                xc=raylrnd(sigma,[2,no]);
                h=plot(xc(1,:),xc(2,:),'.','MarkerSize',6);
                
            end
            for n=1:TargetNum
                
                if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                    
                    sc=Name{n};
                    text(x{n}(round((m-Target{n}(12)))/resolution),y{n}(round((m-Target{n}(12)))/resolution),sc);
                end
                
                if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                    if ViewType~=2
                        break;
                    end
                    plot(x{n}(1:round(((m-Target{n}(12)))/resolution)),sny{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                end
                
                grid on;
                drawnow
                if m==totalTime
                else
                    if clutterchoice==1
                        
                        delete(h);
                    end
                end
            end
        end
    end
end

% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3
global Target resolution totalTime checkCho range TargetNum x y z
global snx sny snz ViewType Name RMS NofClutter clutterchoice
ViewType=3;
hold off
cla(handles.axes1);
axes(handles.axes1)
xlabel('z/m')
ylabel('y/m')
zlabel('z/m')
axis([-range range -range range]);
hold on
t=0:resolution:totalTime;
if get(hObject,'Value')==1
    set(handles.radiobutton1,'Value',0);
    set(handles.radiobutton2,'Value',0);
    set(handles.radiobutton4,'Value',0);
    if checkCho==0
        for m=1:numel(t)
            if clutterchoice==1;
                sigma=str2num(cell2mat(RMS));
                no=str2num(cell2mat(NofClutter));
                xc=raylrnd(sigma,[2,no]);
                h=plot(xc(1,:),xc(2,:),'.','MarkerSize',6);
               
            end
            for n=1:TargetNum
                
                if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                    
                    sc=Name{n};
                    text(y{n}(round((m-Target{n}(12)))/resolution),z{n}(round(m-Target{n}(12))),sc);
                end
                
                if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                    if ViewType~=3
                        break;
                    end
                    plot(sny{n}(1:round((m-Target{n}(12))/resolution)),snz{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                end
                
                grid on;
                drawnow
                if m==totalTime
                else
                    if clutterchoice==1
                        
                        delete(h);
                    end
                end
            end
        end
    end
    if checkCho==1
        for m=1:numel(t)
            if clutterchoice==1;
                sigma=str2num(cell2mat(RMS));
                no=str2num(cell2mat(NofClutter));
                xc=raylrnd(sigma,[2,no]);
                h=plot(xc(1,:),xc(2,:),'.','MarkerSize',6);
                
            end
            for n=1:TargetNum
                
                if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                    
                    sc=Name{n};
                    text(y{n}(round((m-Target{n}(12)))/resolution),z{n}(round(m-Target{n}(12))),sc);
                end
                
                if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                    if ViewType~=3
                        break;
                    end
                    plot(sny{n}(1:round((m-Target{n}(12))/resolution)),snz{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                end
                
                grid on;
                drawnow
                if m==totalTime
                else
                    if clutterchoice==1
                        
                        delete(h);
                    end
                end
            end
        end
    end
    if checkCho==2
        for m=1:numel(t)
            if clutterchoice==1;
                sigma=str2num(cell2mat(RMS));
                no=str2num(cell2mat(NofClutter));
                xc=raylrnd(sigma,[2,no]);
                h=plot(xc(1,:),xc(2,:),'.','MarkerSize',6);
                
            end
            for n=1:TargetNum
                
                if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                    
                    sc=Name{n};
                    text(x{n}(round((m-Target{n}(12)))/resolution),y{n}(round((m-Target{n}(12)))/resolution),z{n}(round(m-Target{n}(12))),sc);
                end
                
                if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                    if ViewType~=3
                        break;
                    end
                    plot(sny{n}(1:round(((m-Target{n}(12)))/resolution)),snz{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                end
                
                grid on;
                drawnow
                if m==totalTime
                else
                    if clutterchoice==1
                        
                        delete(h);
                    end
                end
            end
        end
    end
    
end

% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4
global Target resolution totalTime checkCho range TargetNum x y z
global snx sny snz Name ViewType RMS NofClutter clutterchoice
ViewType=4;
hold off
cla(handles.axes1);
axes(handles.axes1)
xlabel('x/m');
ylabel('z/m')
zlabel('z/m')
axis([0 range -range range]);
hold on
t=0:resolution:totalTime;
if get(hObject,'Value')==1
    set(handles.radiobutton1,'Value',0);
    set(handles.radiobutton2,'Value',0);
    set(handles.radiobutton3,'Value',0);
    if checkCho==0
        for m=1:numel(t)
            if clutterchoice==1;
                sigma=str2num(cell2mat(RMS));
                no=str2num(cell2mat(NofClutter));
                xc=raylrnd(sigma,[2,no]);
                h=plot(xc(1,:),xc(2,:),'.','MarkerSize',6);
                
            end
            for n=1:TargetNum
                
                if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                    
                    sc=Name{n};
                    text(x{n}(round((m-Target{n}(12)))/resolution),y{n}(round((m-Target{n}(12)))/resolution),z{n}(round((m-Target{n}(12)))/resolution),sc);
                end
                
                if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                    if ViewType~=4
                        break;
                    end
                    plot(x{n}(1:round((m-Target{n}(12))/resolution)),z{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                end
                
                grid on;
                drawnow
                if m==totalTime
                else
                    if clutterchoice==1
                        
                        delete(h);
                    end
                end
            end
        end
    end
    if checkCho==1
        for m=1:numel(t)
            if clutterchoice==1;
                sigma=str2num(cell2mat(RMS));
                no=str2num(cell2mat(NofClutter));
                xc=raylrnd(sigma,[2,no]);
                h=plot(xc(1,:),xc(2,:),'.','MarkerSize',6);
                
            end
            for n=1:TargetNum
                
                if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                    
                    sc=Name{n};
                    text(x{n}(round((m-Target{n}(12)))/resolution),y{n}(round((m-Target{n}(12)))/resolution),z{n}(round(m-Target{n}(12))),sc);
                end
                
                if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                    if ViewType~=4
                        break;
                    end
                    plot(x{n}(1:round((m-Target{n}(12))/resolution)),snz{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                end
                
                grid on;
                drawnow
                if m==totalTime
                else
                    if clutterchoice==1
                        
                        delete(h);
                    end
                end
            end
        end
    end
    if checkCho==2
        for m=1:numel(t)
            if clutterchoice==1;
                sigma=str2num(cell2mat(RMS));
                no=str2num(cell2mat(NofClutter));
                xc=raylrnd(sigma,[2,no]);
                h=plot(xc(1,:),xc(2,:),'.','MarkerSize',6);
               
            end
            for n=1:TargetNum
                
                if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                    
                    sc=Name{n};
                    text(x{n}(round((m-Target{n}(12)))/resolution),y{n}(round((m-Target{n}(12)))/resolution),z{n}(round(m-Target{n}(12))),sc);
                end
                
                if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                    if ViewType~=4
                        break;
                    end
                    plot(x{n}(1:round(((m-Target{n}(12)))/resolution)),snz{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                end
                
                grid on;
                drawnow
                if m==totalTime
                else
                    if clutterchoice==1
                        
                        delete(h);
                    end
                end
            end
        end
    end
end
% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Target TargetNum totalTime Name x y z resolution snx sny snz
global mu sigma Time
TargetNum=TargetNum+1;
n=TargetNum;
%ID
Target{n}(1)=str2double(get(handles.edit18,'string'));
%Name
id=['Target ' get(handles.edit18,'string')];
Name{n}=id;
%x
Target{n}(3)=str2double(get(handles.edit9,'string'));
%y
Target{n}(4)=str2double(get(handles.edit10,'string'));
%z
Target{n}(5)=str2double(get(handles.edit11,'string'));
%vx
Target{n}(6)=str2double(get(handles.edit12,'string'));
%vy
Target{n}(7)=str2double(get(handles.edit13,'string'));
%vz
Target{n}(8)=str2double(get(handles.edit14,'string'));
%ax
Target{n}(9)=str2double(get(handles.edit15,'string'));
%ay
Target{n}(10)=str2double(get(handles.edit16,'string'));
%az
Target{n}(11)=str2double(get(handles.edit17,'string'));
%TS
Target{n}(12)=str2double(get(handles.edit26,'string'));
%TE
Target{n}(13)=str2double(get(handles.edit27,'string'));


totalTime=Target{n}(13);
Time{n}=0:resolution:Target{n}(13)-Target{n}(12);
t=Time{n};
x{n}=Target{n}(3)+Target{n}(6).*t+0.5.*Target{n}(9).*t.*t;
y{n}=Target{n}(4)+Target{n}(7).*t+0.5.*Target{n}(10).*t.*t;
z{n}=Target{n}(5)+Target{n}(8).*t+0.5.*Target{n}(11).*t.*t;
snx{n}=x{n}+sigma.*randn(size(t))+mu;
sny{n}=y{n}+sigma.*randn(size(t))+mu;
snz{n}=z{n}+sigma.*randn(size(t))+mu;



set(handles.edit28,'String',totalTime);
set(handles.pushbutton2,'visible','off')
set(handles.pushbutton3,'visible','on')
set(handles.listbox1,'String',Name{n})
set(handles.edit19,'String',TargetNum)

idnum=TargetNum+1;
set(handles.edit18,'String',idnum);

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Target TargetNum totalTime Name x y z snx sny snz resolution sigma mu
global Time
TargetNum=TargetNum+1;
n=TargetNum;
%ID
Target{n}(1)=str2double(get(handles.edit18,'string'));
%Name
id=['Target ' get(handles.edit18,'string')];
Name{n}=id;
%x
Target{n}(3)=str2double(get(handles.edit9,'string'));
%y
Target{n}(4)=str2double(get(handles.edit10,'string'));
%z
Target{n}(5)=str2double(get(handles.edit11,'string'));
%vx
Target{n}(6)=str2double(get(handles.edit12,'string'));
%vy
Target{n}(7)=str2double(get(handles.edit13,'string'));
%vz
Target{n}(8)=str2double(get(handles.edit14,'string'));
%ax
Target{n}(9)=str2double(get(handles.edit15,'string'));
%ay
Target{n}(10)=str2double(get(handles.edit16,'string'));
%az
Target{n}(11)=str2double(get(handles.edit17,'string'));
%TS
Target{n}(12)=str2double(get(handles.edit26,'string'));
%TE
Target{n}(13)=str2double(get(handles.edit27,'string'));

if totalTime<Target{n}(13)
    totalTime=Target{n}(13);
end
set(handles.edit28,'String',totalTime);

idnum=TargetNum+1;
set(handles.edit18,'String',idnum);


NameStr='';
for a=1:TargetNum-1
    NameStr=[NameStr Name{a}];
    NameStr=[NameStr '|'];
end
NameStr=[NameStr Name{TargetNum}];
set(handles.listbox1,'String',NameStr)
set(handles.edit19,'String',TargetNum)

Time{n}=0:resolution:Target{n}(13)-Target{n}(12);
t=Time{n};
x{n}=Target{n}(3)+Target{n}(6).*t+0.5.*Target{n}(9).*t.*t;
y{n}=Target{n}(4)+Target{n}(7).*t+0.5.*Target{n}(10).*t.*t;
z{n}=Target{n}(5)+Target{n}(8).*t+0.5.*Target{n}(11).*t.*t;
snx{n}=x{n}+sigma.*randn(size(t))+mu;
sny{n}=y{n}+sigma.*randn(size(t))+mu;
snz{n}=z{n}+sigma.*randn(size(t))+mu;


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global selid totalTime Target TargetNum resolution x y z snx sny snz
global sigma mu
%x
Target{selid}(3)=str2double(get(handles.edit9,'string'));
%y
Target{selid}(4)=str2double(get(handles.edit10,'string'));
%z
Target{selid}(5)=str2double(get(handles.edit11,'string'));
%vx
Target{selid}(6)=str2double(get(handles.edit12,'string'));
%vy
Target{selid}(7)=str2double(get(handles.edit13,'string'));
%vz
Target{selid}(8)=str2double(get(handles.edit14,'string'));
%ax
Target{selid}(9)=str2double(get(handles.edit15,'string'));
%ay
Target{selid}(10)=str2double(get(handles.edit16,'string'));
%az
Target{selid}(11)=str2double(get(handles.edit17,'string'));
%TS
Target{selid}(12)=str2double(get(handles.edit26,'string'));
%TE
Target{selid}(13)=str2double(get(handles.edit27,'string'));

if totalTime<Target{selid}(13)
    totalTime=Target{selid}(13);
end
n=selid;
t=0:resolution:Target{selid}(13)-Target{selid}(12);

x{n}=Target{n}(3)+Target{n}(6).*t+0.5.*Target{n}(9).*t.*t;
y{n}=Target{n}(4)+Target{n}(7).*t+0.5.*Target{n}(10).*t.*t;
z{n}=Target{n}(5)+Target{n}(8).*t+0.5.*Target{n}(11).*t.*t;
snx{n}=x{n}+sigma.*randn(size(t))+mu;
sny{n}=y{n}+sigma.*randn(size(t))+mu;
snz{n}=z{n}+sigma.*randn(size(t))+mu;
set(handles.edit28,'String',totalTime);
set(handles.edit18,'String',TargetNum+1)
set(handles.pushbutton4,'Visible','off');
set(handles.pushbutton3,'Visible','on');
set(handles.pushbutton7,'Visible','off');


function edit18_Callback(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit18 as text
%        str2double(get(hObject,'String')) returns contents of edit18 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','1')
end

% --- Executes during object creation, after setting all properties.
function edit18_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit19_Callback(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit19 as text
%        str2double(get(hObject,'String')) returns contents of edit19 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Target resolution totalTime checkCho range TargetNum x y z
global snx sny snz ViewType Name

t=1:resolution:totalTime;
fp=fopen('OutputData.txt','wt+');
fprintf(fp,'ID          ');
fprintf(fp,'x           ');
fprintf(fp,'y           ');
fprintf(fp,'z           ');
fprintf(fp,'t\n');
if checkCho==0
    for m=1:numel(t)
        
        for n=1:TargetNum
            
            if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                
                sc=Name{n};
                
            end
            
            if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                
                %plot3(x{n}(1:round((m-Target{n}(12))/resolution)),y{n}(1:round((m-Target{n}(12))/resolution)),z{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                
                if round( m-Target{n}(12))>0
                    fprintf(fp,'%d    ',n);
                    fprintf(fp,'%f    ',x{n}(round((m-Target{n}(12))/resolution)));
                    fprintf(fp,'%f    ',y{n}(round((m-Target{n}(12))/resolution)));
                    fprintf(fp,'%f    ',z{n}(round((m-Target{n}(12))/resolution)));
                    fprintf(fp,'%f\n',m);
                end
            end
            
            grid on;
            drawnow
        end
    end
    fclose(fp);
end

if checkCho==1
    for m=1:numel(t)
        
        for n=1:TargetNum
            
            if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                
                sc=Name{n};
                % text(x{n}(round((m-Target{n}(12)))/resolution),sny{n}(round((m-Target{n}(12)))/resolution),snz{n}(round(m-Target{n}(12))),sc);
            end
            
            if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                
                %plot3(x{n}(1:round((m-Target{n}(12))/resolution)),sny{n}(1:round((m-Target{n}(12))/resolution)),snz{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                if round( m-Target{n}(12))>0
                    fprintf(fp,'%d    ',n);
                    fprintf(fp,'%f    ',x{n}(round((m-Target{n}(12))/resolution)));
                    fprintf(fp,'%f    ',sny{n}(round((m-Target{n}(12))/resolution)));
                    fprintf(fp,'%f    ',snz{n}(round((m-Target{n}(12))/resolution)));
                    fprintf(fp,'%f\n',m);
                end
            end
            
            grid on;
            drawnow
        end
    end
    fclose(fp);
end
if checkCho==2
    for m=1:numel(t)
        
        for n=1:TargetNum
            
            if m-Target{n}(12)==Target{n}(13)-Target{n}(12)
                
                sc=Name{n};
                % text(x{n}(round((m-Target{n}(12)))/resolution),sny{n}(round((m-Target{n}(12)))/resolution),snz{n}(round(m-Target{n}(12))),sc);
            end
            
            if round( m-Target{n}(12))<Target{n}(13)-Target{n}(12)
                
                % plot3(x{n}(1:round(((m-Target{n}(12)))/resolution)),sny{n}(1:round((m-Target{n}(12))/resolution)),snz{n}(1:round((m-Target{n}(12))/resolution)),'-r');
                if round( m-Target{n}(12))>0
                    fprintf(fp,'%d    ',n);
                    fprintf(fp,'%f    ',x{n}(round((m-Target{n}(12))/resolution)));
                    fprintf(fp,'%f    ',sny{n}(round((m-Target{n}(12))/resolution)));
                    fprintf(fp,'%f    ',snz{n}(round((m-Target{n}(12))/resolution)));
                    fprintf(fp,'%f\n',m);
                end
            end
            
            grid on;
            drawnow
        end
    end
    fclose(fp);
end





function edit20_Callback(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit20 as text
%        str2double(get(hObject,'String')) returns contents of edit20 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit20_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1
global checkCho
if get(hObject,'Value')==1
    checkCho=1;
    set(handles.pushbutton6,'enable','on')
    set(handles.edit20,'enable','on')
    set(handles.edit21,'enable','on')
    set(handles.checkbox2,'enable','off')
else
    checkCho=0;
    set(handles.pushbutton6,'enable','off')
    set(handles.edit20,'enable','off')
    set(handles.edit21,'enable','off')
    set(handles.checkbox2,'enable','on')
end
function edit21_Callback(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit21 as text
%        str2double(get(hObject,'String')) returns contents of edit21 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end


% --- Executes during object creation, after setting all properties.
function edit21_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2
global checkCho
if get(hObject,'Value')==1
    checkCho=2;
    set(handles.pushbutton6,'enable','on')
    set(handles.edit22,'enable','on')
    set(handles.checkbox1,'enable','off')
    set(handles.popupmenu1,'enable','on')
else
    checkCho=0;
    set(handles.pushbutton6,'enable','off')
    set(handles.edit22,'enable','off')
    set(handles.popupmenu1,'enable','off')
    set(handles.checkbox1,'enable','on')
end


function edit22_Callback(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit22 as text
%        str2double(get(hObject,'String')) returns contents of edit22 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end

% --- Executes during object creation, after setting all properties.
function edit22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
global snrType
contents = cellstr(get(hObject,'String')) ;
str=contents{get(hObject,'Value')};
switch str
    case 'dB'
        snrType=1;
    case 'linear'
        snrType=2;
end

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global checkCho mu sigma snr resolution Target totalTime x y z
global snx sny snz snrType Time TargetNum
if checkCho==1
    mu=str2double(get(handles.edit20,'String'));
    sigma=str2double(get(handles.edit21,'String'));
    
    
    for n=1:TargetNum
        snx{n}=x{n}+sigma.*randn(size(Time{n}))+mu;
        sny{n}=y{n}+sigma.*randn(size(Time{n}))+mu;
        snz{n}=z{n}+sigma.*randn(size(Time{n}))+mu;
    end
end
if checkCho==2
    snr=str2double(get(handles.edit22,'String'));
    if snrType==1
        for n=1:TargetNum
            snx{n}=awgn(x{n},snr,'measured','dB');
            sny{n}=awgn(y{n},snr,'measured','dB');
            snz{n}=awgn(z{n},snr,'measured','dB');
        end
    end
    if snrType==2
        snx{n}=awgn(x{n},snr,'measured','linear');
        sny{n}=awgn(y{n},snr,'measured','linear');
        snz{n}=awgn(z{n},snr,'measured','linear');
    end
end



function edit26_Callback(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit26 as text
%        str2double(get(hObject,'String')) returns contents of edit26 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end

% --- Executes during object creation, after setting all properties.
function edit26_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit27_Callback(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit27 as text
%        str2double(get(hObject,'String')) returns contents of edit27 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end

% --- Executes during object creation, after setting all properties.
function edit27_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit28_Callback(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit28 as text
%        str2double(get(hObject,'String')) returns contents of edit28 as a double
input = str2double(get(hObject,'String'));
if(isempty(input))
    set(hObject,'String','0')
end

% --- Executes during object creation, after setting all properties.
function edit28_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global TargetNum selid Name
prompt='Please Input Target Name : ';
name='Rename';
defaultans={Name{selid}};
options.Interpreter = 'tex';
value=inputdlg(prompt,name,[1 40],defaultans,options);

if isempty(value)==1
    
else
    Name{selid}=cell2mat(value);
end

NameStr='';
for a=1:TargetNum-1
    NameStr=[NameStr Name{a}];
    NameStr=[NameStr '|'];
end
NameStr=[NameStr Name{TargetNum}];
set(handles.listbox1,'String',NameStr)


% --- Executes on button press in pushbutton14.
function pushbutton14_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.edit18,'Enable','off')
set(handles.edit19,'Enable','off')
set(handles.edit28,'Enable','off')
set(handles.pushbutton3,'visible','off')
set(handles.pushbutton4,'visible','off')
set(handles.pushbutton7,'visible','off')
set(handles.pushbutton6,'enable','off')
set(handles.edit20,'enable','off')
set(handles.edit21,'enable','off')
set(handles.edit22,'enable','off')
set(handles.popupmenu1,'enable','off')
set(handles.popupmenu1,'string','dB|Linear')
set(handles.checkbox4,'enable','off')
set(handles.checkbox5,'enable','off')
set(handles.checkbox6,'enable','off')
global TargetNum
TargetNum=0;

global resolution
resolution=1;

global range
range=0;

global totalTime
totalTime=0;
global checkCho
checkCho=0;

global mu
mu=0;
global sigma
sigma=0;
global snr
snr=0;
global snrType
snrType=1;

global RMS NofClutter defaultans clutterchoice
clutterchoice=0;
RMS=0;
NofClutter=0;
defaultans={};
string='0';
defaultans(1,1)={string};
defaultans(1,2)={string};
set(handles.edit1,'string','1');
set(handles.edit1,'enable','on');
set(handles.edit2,'string','0');
set(handles.edit2,'enable','on');
set(handles.pushbutton1,'enable','on');
set(handles.edit18,'string','1');
set(handles.edit9,'string','0');
set(handles.edit10,'string','0');
set(handles.edit11,'string','0');
set(handles.edit12,'string','0');
set(handles.edit13,'string','0');
set(handles.edit14,'string','0');
set(handles.edit15,'string','0');
set(handles.edit16,'string','0');
set(handles.edit17,'string','0');
set(handles.edit26,'string','0');
set(handles.edit27,'string','0');
set(handles.edit28,'string','0');
set(handles.edit19,'string','0');
set(handles.pushbutton2,'visible','on')
set(handles.pushbutton3,'visible','off')
Namestr=['None'];
set(handles.listbox1,'String',Namestr);
set(handles.pushbutton6,'enable','off')
set(handles.edit20,'enable','off')
set(handles.edit21,'enable','off')
set(handles.edit22,'enable','off')
set(handles.edit20,'string','0')
set(handles.edit21,'string','0')
set(handles.edit22,'string','0')
set(handles.checkbox2,'enable','on')
set(handles.checkbox1,'enable','on')
set(handles.checkbox3,'value',0)
set(handles.checkbox2,'value',0)
set(handles.checkbox1,'value',0)
set(handles.radiobutton1,'value',0)
cla;
fp=fopen('OutputData.txt','wt+')
fprintf(fp,'ID          ');
    fprintf(fp,'t           ');
    fprintf(fp,'x           ');
    fprintf(fp,'y           ');
    fprintf(fp,'z\n');
fclose(fp);
% --- Executes on selection change in popupmenu2.
function popupmenu2_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu2


% --- Executes during object creation, after setting all properties.
function popupmenu2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3
global clutterchoice
if get(hObject,'Value')==1;
    clutterchoice=1;
else
    clutterchoice=0;
end

% --- Executes on button press in pushbutton15.
function pushbutton15_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global RMS NofClutter defaultans
answer=defaultans;
prompt = {'Enter mean squared value:','Enter number of clutter points:'};
dlg_title = 'Input';
%num_lines = 1;

RMS=answer(1);
NofClutter=answer(2);
answer = inputdlg(prompt,dlg_title,[1 50;1 50],defaultans);
if isempty(answer)==1
    
    
else
    defaultans=answer';
    RMS=answer(1);
    NofClutter=answer(2);
end

% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4


% --- Executes on button press in pushbutton16.
function pushbutton16_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in checkbox5.
function checkbox5_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox5


% --- Executes on button press in pushbutton17.
function pushbutton17_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in checkbox6.
function checkbox6_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox6


% --- Executes on button press in pushbutton18.
function pushbutton18_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
